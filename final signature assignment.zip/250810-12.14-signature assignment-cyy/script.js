   /**
 * Campus Community Services - Main JavaScript File
 * Student: Haoyu Cai
 * Course: ITC 2400
 * Signature Assignment
 * File: main.js
 * Last Modified: December 2025
 */

// ==============================================
// DOM READY FUNCTION
// ==============================================

/**
 * Initialize all functionality when DOM is fully loaded
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('Campus Community Services website loaded');
    
    // Initialize common functionality
    initializeCommonFeatures();
    
    // Page-specific initializations
    initializePageFeatures();
    
    // Set up event listeners
    setupEventListeners();
});

// ==============================================
// COMMON FEATURES INITIALIZATION
// ==============================================

/**
 * Initialize features common to all pages
 */
function initializeCommonFeatures() {
    // Update copyright year dynamically
    updateCopyrightYear();
    
    // Initialize mobile navigation if needed
    initializeMobileNav();
    
    // Set active navigation link based on current page
    setActiveNavLink();
    
    // Add smooth scrolling to anchor links
    enableSmoothScrolling();
}

/**
 * Initialize page-specific features
 */
function initializePageFeatures() {
    const currentPage = window.location.pathname.split('/').pop();
    
    switch(currentPage) {
        case 'index.html':
        case '':
            initializeHomePage();
            break;
        case 'services.html':
            initializeServicesPage();
            break;
        case 'contact.html':
            initializeContactPage();
            break;
        default:
            console.log('Page-specific features not defined for:', currentPage);
    }
}

/**
 * Update copyright year dynamically
 */
function updateCopyrightYear() {
    const copyrightElements = document.querySelectorAll('.copyright p:first-child');
    const currentYear = new Date().getFullYear();
    
    copyrightElements.forEach(function(element) {
        element.innerHTML = element.innerHTML.replace('2023', currentYear);
    });
}

/**
 * Initialize mobile navigation for smaller screens
 */
function initializeMobileNav() {
    // Check if we're on mobile
    if (window.innerWidth < 768) {
        const nav = document.querySelector('.main-nav ul');
        if (nav) {
            nav.classList.add('mobile-nav');
        }
    }
}

/**
 * Set active navigation link based on current page
 */
function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(function(link) {
        link.classList.remove('active');
        
        const linkHref = link.getAttribute('href');
        if (currentPage === linkHref || 
            (currentPage === '' && linkHref === 'index.html')) {
            link.classList.add('active');
        }
    });
}

/**
 * Enable smooth scrolling for anchor links
 */
function enableSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Only handle internal page anchors
            if (href.startsWith('#') && href.length > 1) {
                e.preventDefault();
                const targetElement = document.querySelector(href);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Update URL without page reload
                    history.pushState(null, null, href);
                }
            }
        });
    });
}

// ==============================================
// HOME PAGE FUNCTIONS
// ==============================================

/**
 * Initialize home page specific features
 */
function initializeHomePage() {
    console.log('Initializing home page features');
    
    // Initialize service cards interaction
    initializeServiceCards();
    
    // Set up any home page specific event listeners
    setupHomePageListeners();
}

/**
 * Initialize interactive service cards
 */
function initializeServiceCards() {
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(function(card) {
        // Add hover effect
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
        });
        
        // Add click animation
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
}

// ==============================================
// SERVICES PAGE FUNCTIONS
// ==============================================

/**
 * Initialize services page specific features
 */
function initializeServicesPage() {
    console.log('Initializing services page features');
    
    // Initialize service item interactions
    initializeServiceItems();
    
    // Initialize local partner links
    initializePartnerLinks();
}

/**
 * Initialize service items for interactivity
 */
function initializeServiceItems() {
    const serviceItems = document.querySelectorAll('.service-item');
    
    serviceItems.forEach(function(item, index) {
        // Add animation delay based on index
        item.style.animationDelay = `${index * 0.1}s`;
        
        // Add expand/collapse functionality for mobile
        if (window.innerWidth < 768) {
            const title = item.querySelector('.service-title');
            const details = item.querySelector('.service-details');
            
            if (title && details) {
                title.style.cursor = 'pointer';
                
                title.addEventListener('click', function() {
                    details.classList.toggle('expanded');
                    
                    if (details.classList.contains('expanded')) {
                        details.style.maxHeight = details.scrollHeight + 'px';
                    } else {
                        details.style.maxHeight = '0';
                    }
                });
            }
        }
    });
}

/**
 * Initialize partner links with tracking
 */
function initializePartnerLinks() {
    const partnerLinks = document.querySelectorAll('.local-partners a');
    
    partnerLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            // In a real application, you might want to track these clicks
            console.log('Partner link clicked:', this.href);
            // Could send analytics data here
        });
    });
}

// ==============================================
// CONTACT PAGE FUNCTIONS
// ==============================================

/**
 * Initialize contact page specific features
 */
function initializeContactPage() {
    console.log('Initializing contact page features');
    
    // Note: Form validation is handled in validation.js
    // Here we just set up any additional contact page features
    
    // Initialize map interaction
    initializeMap();
    
    // Set up form reset confirmation
    setupFormReset();
}

/**
 * Initialize interactive map features
 */
function initializeMap() {
    const mapPlaceholder = document.querySelector('.map-placeholder');
    
    if (mapPlaceholder) {
        mapPlaceholder.addEventListener('click', function() {
            // In a real application, this might open a modal with a larger map
            alert('In a complete implementation, this would open an interactive campus map.');
        });
    }
}

/**
 * Set up form reset with confirmation
 */
function setupFormReset() {
    const resetButton = document.getElementById('resetButton');
    
    if (resetButton) {
        resetButton.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to clear all form fields?')) {
                e.preventDefault();
            }
        });
    }
}

// ==============================================
// UTILITY FUNCTIONS
// ==============================================

/**
 * Format text with proper capitalization
 * @param {string} text - Text to format
 * @returns {string} Formatted text
 */
function formatText(text) {
    if (!text) return '';
    
    return text.toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} True if email is valid
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validate US zip code format
 * @param {string} zipCode - Zip code to validate
 * @returns {boolean} True if zip code is valid
 */
function isValidZipCode(zipCode) {
    const zipRegex = /^\d{5}(-\d{4})?$/;
    return zipRegex.test(zipCode);
}

/**
 * Validate phone number format
 * @param {string} phone - Phone number to validate
 * @returns {boolean} True if phone number is valid
 */
function isValidPhone(phone) {
    const phoneRegex = /^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
    return phoneRegex.test(phone);
}

/**
 * Debounce function for performance optimization
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ==============================================
// EVENT LISTENER SETUP
// ==============================================

/**
 * Set up global event listeners
 */
function setupEventListeners() {
    // Window resize handling
    window.addEventListener('resize', debounce(handleResize, 250));
    
    // Print styles
    window.addEventListener('beforeprint', handlePrint);
    window.addEventListener('afterprint', handleAfterPrint);
}

/**
 * Handle window resize events
 */
function handleResize() {
    console.log('Window resized:', window.innerWidth, 'x', window.innerHeight);
    
    // Reinitialize mobile navigation if needed
    initializeMobileNav();
}

/**
 * Handle print events
 */
function handlePrint() {
    document.body.classList.add('printing');
}

/**
 * Handle after print events
 */
function handleAfterPrint() {
    document.body.classList.remove('printing');
}

/**
 * Set up home page specific event listeners
 */
function setupHomePageListeners() {
    // Add any home page specific listeners here
}

// ==============================================
// GLOBAL VARIABLES
// ==============================================

const CONFIG = {
    siteName: 'Campus Community Services',
    contactEmail: 'info@campus-services.edu',
    apiBaseUrl: '/api',
    debugMode: true
};

// Export for module usage (if using ES6 modules)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeCommonFeatures,
        formatText,
        isValidEmail,
        isValidZipCode,
        isValidPhone,
        CONFIG
    };
}

// ==============================================
// DEBUG UTILITIES
// ==============================================

if (CONFIG.debugMode) {
    // Log page load time
    window.addEventListener('load', function() {
        const loadTime = window.performance.timing.domContentLoadedEventEnd - 
                        window.performance.timing.navigationStart;
        console.log('Page fully loaded in', loadTime, 'ms');
    });
}